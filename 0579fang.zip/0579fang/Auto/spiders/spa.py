# -*- coding: utf-8 -*-
import scrapy
from Auto.items import AutoItem
#http://www.0579fw.com/agency/list-outold.aspx?page=1

# class SpaSpider(scrapy.Spider):
#     name = "spa"
#     allowed_domains = ["www.0579fw.com"]
#     start_urls = ['http://www.0579fw.com/']

class SpaSpider(scrapy.Spider):
    name = "spa"
    allowed_domains = ["www.0579fw.com"]
    urllist=[]
    for i in range(1500):
        url='http://www.0579fw.com/agency/list-outold.aspx?page='+str(i)
        urllist.append(url)
    # start_urls = ['http://www.0579fw.com/agency/list-outold.aspx?page=1'
    #               ]
    start_urls = urllist

    def parse(self, response):
        Item=AutoItem()
        Item['title']=response.xpath("//tr/td/h3/a/text()").extract()
        Item['address'] = response.xpath("//div/p/span[@class='Address']/text()").extract()
        Item['jiegou'] = response.xpath("//div[@class='roomdetail']/p[2]/span[1]/text()").extract()
        Item['floor']=response.xpath("//div[@class='roomdetail']/p[2]/span[3]/text()").extract()
        Item['orientation']=response.xpath("//div[@class='roomdetail']/p[2]/span[5]/text()").extract()
        Item['agency']=response.xpath("//div[@class='roomdetail']/p[3]/span[1]/a/text()").extract()
        Item['follow']=response.xpath("//div[@class='roomdetail']/p[3]/span[2]/text()").extract()
        Item['date']=response.xpath("//div[@class='roomdetail']/p[3]/span[3]/text()").extract()
        Item['area']=response.xpath("//td[@class='Area']/text()").extract()
        Item['Price']=response.xpath("//td[@class='Price']/p[1]/text()").extract()
        Item['univalent']=response.xpath("//td[@class='Price']/p[2]/text()").extract()
        yield Item
