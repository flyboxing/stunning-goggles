# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class AutoItem(scrapy.Item):
    title = scrapy.Field()
    address=scrapy.Field()
    jiegou=scrapy.Field()
    floor=scrapy.Field()
    orientation=scrapy.Field()
    agency=scrapy.Field()
    follow=scrapy.Field()
    date=scrapy.Field()
    area=scrapy.Field()
    Price=scrapy.Field()
    univalent=scrapy.Field()

