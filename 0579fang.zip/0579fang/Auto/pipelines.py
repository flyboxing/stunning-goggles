# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


import numpy as np
import pandas as pd
import csv
from Auto.spiders import spa
class titlePipeline(object):

    def __init__(self):
        self.s=open('opec.csv','a',newline='')

    def process_item(self, item, spider):
        list=[]
        for i in range(len(item['title'])):

            line=[(item['title'][i]),(item['address'][i]),(item['area'][i]),(item['Price'][i]),(item['univalent'][i])\
                ,(item['floor'][i]),(item['follow'][i]),(item['date'][i]),(item['agency'][i])]
            writer=csv.writer(self.s)
            writer.writerow(line)
            # self.file.write(line)
        return item

